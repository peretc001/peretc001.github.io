<?php session_start();
	include ($_SERVER['DOCUMENT_ROOT'] .'/inc/check.php');
	
	# Подключаем файл конфигурации
	include $_SERVER['DOCUMENT_ROOT'] .'/inc/safemysql.class.php';
	
	$db = new SafeMySQL();

	$row = $db->getRow('SELECT * FROM `company` WHERE company_code = ?s', $_POST['company_code']);

	if($row) {

		$id = $row['id'];

	} else {

	if($_POST['company_date'] != '') { $company_date = date('Y-m-d', strtotime($_POST['company_date'])); } 
	if($_POST['company_date'] == '') { $company_date = '0000-00-00'; }
	if($_POST['company_time'] == '') { $_POST['company_time'] = '00:00:00'; }
	
	$data = array('company_name' => $_POST['company_name'], 'company_code' => $_POST['company_code'], 'company_region' => $_POST['company_region'], 'company_adres' => $_POST['company_adres'], 'company_about' => $_POST['company_about'], 'company_date' => $company_date,  'company_time' => $_POST['company_time'], 'company_manager' => $_POST['company_manager'] );
	
	$db->query("INSERT INTO company SET ?u", $data);

	$inn = $db->getRow('SELECT * FROM `company` WHERE company_name = ?s', $_POST['company_name']);
	$id = $inn['id'];
		
	}	
		echo '<script language="JavaScript">
			window.location.href = "/company_page.php?id='. $id .'"
		</script>';
	
?>
