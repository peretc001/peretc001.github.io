<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="content-type" content="text/html; charset=utf-8">
	<link rel="shortcut icon" href="img/favicon.png">
	<style>
		body {
			opacity: 0;
			overflow-x: hidden;
		}

		html {
			background-color: #fff;
		}
	</style>
</head>