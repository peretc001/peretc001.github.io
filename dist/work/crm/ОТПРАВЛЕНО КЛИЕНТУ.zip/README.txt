1. Скопировать все файлы в корень сайта
2. Создать базу данных
3. Импортировать в базу все из файла base.sql
4. После настроить подключение к БД, для этого изменить файлы: 
        /inc/safemysql.class.php (класс для безопасной работы с БД)
        и /inc/action/company_list.php (автозаполнение ИНН из БД)
    
    Изменить данные для подключения к БД
    
    В файле /inc/safemysql.class.php Строки 75,76,77,78
      'host'      => 'localhost',
      'user'      => 'user',
      'pass'      => '12345',
      'db'        => 'db_base',

    В файле /inc/action/company_list.php Строку 2
        $db = mysqli_connect("localhost", "user", "12345", "db_base") or die("Нет соединения с БД");

5. Готово

Контакты для связи по адресу http://peretc001.github.io