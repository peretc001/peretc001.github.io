# text

```php
text ( ) : string
```

Returns the (HTML) text representation for the current node recursively.